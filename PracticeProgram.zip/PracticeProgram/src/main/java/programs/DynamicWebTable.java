package programs;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class DynamicWebTable {

	WebDriver driver;

	@Test
	public void maxValue() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nkrishnamoorthy\\Downloads\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://money.rediff.com/gainers/bsc/daily/groupa");
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		List<WebElement> cols = driver.findElements(By.xpath("//*[@class='dataTable']//th"));

		System.out.println("No. of Colums:" + cols.size());

		List<WebElement> rows = driver.findElements(By.xpath("//*[@class='dataTable']//tr"));
		System.out.println("No. of Rows:" + rows.size());

		// Fetching column values of particular row

		Scanner scan = new Scanner(System.in);
		int input = scan.nextInt();

		System.out.println("User entered Row value is:" + input);
		ArrayList<String> cellValue = new ArrayList<String>();
		for (int i = 0; i < rows.size(); i++) {
			if (i == input) {
				for (int j = 1; j <= cols.size(); j++) {
					String value = (driver
							.findElement(By.xpath("//*[@class='dataTable']//tr[" + i + "]/td[" + j + "]"))).getText();

					cellValue.add(value);
					//// *[]//tr[1]/td[1]
				}

				System.out.println("Cell Value is" + cellValue);

			}

		}

	}

}
