package programs;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

public class DropDown {

	public WebDriver driver;
	public static String FILE_PATH = "C:\\Users\\nkrishnamoorthy\\Downloads\\ClearTrip\\PracticeProgram\\Screenshot";
	// public File SCREENSHOT_FILE = new File(FILE_PATH);

	@Test
	public void selectDropdown() throws WebDriverException, IOException {
		String str = "Select Adult Count";

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nkrishnamoorthy\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.cleartrip.com/");

		Select adult = new Select(driver.findElement(By.id("Adults")));

		List<WebElement> list = adult.getOptions();

		int length = list.size();

		for (int i = 0; i <= length - 1; i++) {

			adult.selectByIndex(i);

			System.out.println(i);

		}

		takeScreenshot(str);
	}

	@AfterClass
	public void browserClose() {
		driver.close();
		driver.quit();
	}

	public void takeScreenshot(String stepName) throws WebDriverException, IOException {

		/*
		 * if (!SCREENSHOT_FILE.exists()) { SCREENSHOT_FILE.mkdir(); }
		 */

		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		FileUtils.copyFile(src, new File(FILE_PATH + File.separator + stepName + ".jpg"));

	}

}
