package programs;

public class Employee {

	int empId;
	String empName;
	double empSalary;

	Employee(int empId, String empName, double empSalary) {
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;

	}

	public static void main(String[] args) {

	}

}
