package programs;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class ListExample {

	public static void main(String[] args) {

		ArrayList<String> arrList = new ArrayList<String>();

		arrList.add("aaa");
		arrList.add("bbb");
		arrList.add("ccc");
		arrList.add("ddd");
		arrList.add("eee");
		arrList.add("aaa");
		arrList.add("ggg");
		arrList.add("ccc");
		System.out.println(arrList);

		Iterator<String> itr = arrList.iterator();

		while (itr.hasNext()) {
			System.out.println(itr.next());
		}

		for (String s : arrList) {
			System.out.println(s);
		}

		Employee e1 = new Employee(111, "abhi", 15000.4505);
		Employee e2 = new Employee(222, "binay", 50000.8950);
		Employee e3 = new Employee(333, "vikas", 8000.665);

		/*
		 * List<Employee> empArr = new ArrayList<Employee>(); 
		 * Set<Employee> empSet = new HashSet<Employee>(); 
		 * Set<Employee> empSet = new LinkedHashSet<Employee>();
		 * empSet.add(e3); 
		 * empSet.add(e2); 
		 * empArr.add(e3); 
		 * empSet.add(e1);
		 * 
		 * for (Employee empObj:empSet) 
		 * {
		 * System.out.println(empObj.empId+"*****"+empObj.empName+"*****"+empObj.empSalary); 
		 * }
		 *
		 * Iterator itr = empArr.iterator();
		 * 
		 * while (itr.hasNext()) { Employee ee = (Employee)itr.next();
		 * System.out.println(ee.empId+"-----"+ee.empName+"-----"+ee.empSalary);
		 */
	}

}
