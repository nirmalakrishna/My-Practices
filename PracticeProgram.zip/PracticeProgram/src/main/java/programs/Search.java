package programs;

import java.util.Scanner;

public class Search {

	public static void main(String[] args) {

		int counter, numbers, item, array[];

		Scanner input = new Scanner(System.in);
		System.out.println("Enter Count:");
		numbers = input.nextInt();
		array = new int[numbers];

		for (counter = 0; counter < numbers; counter++) {
			System.out.println("Enter the Number:");
			array[counter] = input.nextInt();
		}
		System.out.println("Enter the value to be searched:");
		item = input.nextInt();

		for (counter = 0; counter < numbers; counter++) {
			if (array[counter] == item) {
				System.out.println(array[counter] + " value matched");
				System.out.println("Value present at Location: " + (counter + 1));
				break;
			}
		}
		if (counter == numbers) {

			System.out.println(item + " does not match the array list");
		}

	}

	/*
	 * int counter, num, item, array[];
	 * 
	 * Scanner input = new Scanner(System.in);
	 * System.out.println("Enter number of elements:"); num = input.nextInt();
	 * array = new int[num]; System.out.println("Enter " + num + " integers");
	 * for (counter = 0; counter < num; counter++) array[counter] =
	 * input.nextInt(); System.out.println("Enter the search value:"); item =
	 * input.nextInt(); for (counter = 0; counter < num; counter++) { if
	 * (array[counter] == item) { System.out.println(item +
	 * " is present at location " + (counter + 1));
	 * 
	 * break; } } if (counter == num) System.out.println(item +
	 * " doesn't exist in array.");
	 */
}
