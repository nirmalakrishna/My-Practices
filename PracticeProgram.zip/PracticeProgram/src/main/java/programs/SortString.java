package programs;

import java.util.Arrays;

public class SortString {

	public static void main(String[] args) {
		
String[] input={"Jan", "Feb", "Mar", "Apr", "Feb", "Mar", "Jan", "Jun", "May" };

//System.out.println(input[0]);

Arrays.sort(input);


for(String st: input){
	
System.out.println(st+"\n"); 
	
}

	}

}
