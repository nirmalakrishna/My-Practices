package programs;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class MaxValueInCol {

	WebDriver wd;
	String num1;
	Double x=0.00;
	Double result;

	@Test
	public void findMax() throws ParseException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nkrishnamoorthy\\Downloads\\chromedriver_win32\\chromedriver.exe");

		wd = new ChromeDriver();
		wd.get("https://money.rediff.com/gainers/bsc/daily/groupa");
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		wd.manage().window().maximize();

		List<WebElement> rows = wd.findElements(By.xpath("//*[@class='dataTable']//tr"));
		int rowSize = rows.size();
		System.out.println("No. of Rows:" + rowSize);

		for (int i = 1; i < rowSize; i++) {
			String cellValue = wd.findElement(By.xpath("//*[@class='dataTable']//tr[" + i + "]/td[4]")).getText();
			NumberFormat nf = NumberFormat.getNumberInstance();
			Number num = nf.parse(cellValue);
			cellValue = num.toString();
			result = Double.parseDouble(cellValue);

			if (result > x) {
				x = result;
			}

		}
		System.out.println("The Maximum Current Price is:" + x);
	}

}
