package programs;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ScreenShot {

	static WebDriver driver;
	static File fil;
	static WebElement ele;
	static String path1 = "D:\\Highlighted_Image.jpg";
	static String path2 = "D:\\Screenshot_Image.jpg";

	public static void main(String[] args) throws IOException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nkrishnamoorthy\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.get("https://money.rediff.com/gainers/bsc/daily/groupa");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		ele = driver.findElement(By.partialLinkText("Investment Tool"));
		fil = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		System.out.println("Screenshot Captured");

		ScreenShot ss = new ScreenShot();
		ss.imageHighlight(path1);
		ss.imageCrop(path2);
		driver.close();
	}

	public void imageHighlight(String str) throws IOException {
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("arguments[0].style.border='3px solid red'", ele);
		System.out.println("Element Highlighted");
		FileUtils.copyFile(fil, new File(str));
	}

	public void imageCrop(String str) throws IOException {
		Point pt = ele.getLocation();
		int x = pt.getX();
		int y = pt.getY();
		int h = ele.getSize().height;
		int w = ele.getSize().width;
		BufferedImage buff = ImageIO.read(fil);
		BufferedImage modified = buff.getSubimage(x, y, w, h);
		ImageIO.write(modified, "jpg", fil);

		FileUtils.copyFile(fil, new File(path2));

	}
}
