package programs;

import java.io.IOException;
import java.net.*;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class BrokenLinks {

	WebDriver driver;
	String url = "";
	HttpURLConnection huc = null;
	int resCode;

	@Test
	public void getAllLinks() throws MalformedURLException, IOException {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nkrishnamoorthy\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.google.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		driver.findElement(By.name("q")).sendKeys("Selenium Tutorial");
		driver.findElement(By.name("btnK")).click();

		List<WebElement> linklist = driver.findElements(By.tagName("a"));
		System.out.println(linklist.size());

		for (WebElement link : linklist) {
			url = link.getAttribute("href");

			if (url == null || url.isEmpty()) {
				System.out.println(url + "URL is either not configured for anchor tag or it is empty");
				continue;
			}
			huc = (HttpURLConnection) (new URL(url).openConnection());
			huc.setRequestMethod("HEAD");
			huc.connect();
			resCode = huc.getResponseCode();
			System.out.println(huc.getResponseMessage());

			if (resCode >= 400) {
				System.out.println(url + "The link is broken or unable to establish connection");
			} else {
				System.out.println(url + "---->The link is valid");
			}
		}
		driver.close();
	}
}