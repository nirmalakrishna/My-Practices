package programs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

public class ReadPropertyFile {

	public static void main(String[] args) throws IOException {

		FileInputStream fis = new FileInputStream("./data/config.properties");
	//	FileOutputStream fos = new FileOutputStream("./data/config.properties");

		Properties prop = new Properties();

		prop.load(fis);

		String str = prop.getProperty("name");
		Object str1 = prop.get("day");
		System.out.println(str);
		System.out.println(str1);

	//	prop.setProperty("time", "now");
	//	prop.store(fos, null);
		
		Enumeration e = prop.propertyNames();
		 while(e.hasMoreElements()){
			 String key = (String) e.nextElement();
			 String value = prop.getProperty(key);
			 System.out.println(key + ":" + value);
		 }
		

	}

}
