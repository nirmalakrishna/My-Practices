package programs;

public class Variables {

	int salary;
	String empName;
	static String  companyName;
	
	public static void main(String[] argument) {
		
	/*	companyName = "CTS";
		Variables var = new Variables();
		var.empName="Nirmala";
		var.salary=10000;
		
		
		Variables var1 = new Variables();
		var1.empName="Krishna";
		var1.salary=15000;
		
		var.printDetails();
		var1.printDetails();
		
			
		companyName = "Hexaware";
		var.salary = 50000;
		
		var.printDetails();
		var1.printDetails();
		Variables var2 = new Variables();
		var2.empDetails(); */
	}
	

	public void printDetails(){
		
		
		System.out.println("Employee Details:" + empName);
		System.out.println("Employee Details:" + salary);
		System.out.println("Employee Details:" + companyName);
		
	}
	
	public void empDetails(){
		
	/*	salary = 2000;
		empName = "Mallika";
		companyName = "Verizon";
		System.out.println("Employee Details:" + empName);
		System.out.println("Employee Details:" + salary);
		System.out.println("Employee Details:" + companyName); */
	}

	
}
