package programs;

import java.util.Scanner;

public class EvenorOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner input = new Scanner(System.in);
		System.out.println("Enter any Number:");
		int numbers = input.nextInt();
		if ((numbers % 2) == 0) {
			System.out.println("The given number is Even");
		} else {
			System.out.println("The given number is Odd");
		}
	}

}
