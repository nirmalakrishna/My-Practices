package programs;

public class Constructor {
	int i = 10;

	public static void main(String[] args) {
		
		// As i is an static variable it can be accessed directly without using
		// any object
		//System.out.println("Value before calling method1: " + i);

		Constructor t1 = new Constructor();
		t1.method1();
		//System.out.println("Value after calling method1: " + i);

		Constructor t2 = new Constructor();
		t2.method2();
		//System.out.println("Value after calling method2: " + i);
	}

	void method1() {
		i++;
		System.out.println("Value after calling method1: " + i);
	}

	void method2() {
		i++;
		System.out.println("Value after calling method2: " + i);

	}

}
