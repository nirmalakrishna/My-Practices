package programs;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.security.UserAndPassword;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class WinPopUp {
	WebDriver driver;

	@Test
	public void userLogin() {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nkrishnamoorthy\\Downloads\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("https://qbwidit9051.development.webmd.net/q-bwidit9001_TM/index.cfm");

		WebDriverWait wait = new WebDriverWait(driver, 5);
		Alert ale = wait.until(ExpectedConditions.alertIsPresent());
		System.out.println("Alert Identified");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		System.out.println("maximized");

		//Alert alert = driver.switchTo().alert();
		System.out.println("Alert Identified");
		ale.authenticateUsing(new UserAndPassword("development\nkrishnamoorthy", "Jag(6789"));
		// ale.authenticateUsing(new
		// UserAndPassword("development\nkrishnamoorthy", "Jag(6789"));

		// Alert alert = driver.switchTo().alert();
		//alert.accept();

	}
	
	@AfterTest
	public void closeBrowser(){
		driver.quit();
	}
	

}
