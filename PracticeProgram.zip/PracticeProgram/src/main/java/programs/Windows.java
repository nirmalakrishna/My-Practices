package programs;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Windows {

	WebDriver driver;

	@BeforeMethod
	public void launchBrowser() {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nkrishnamoorthy\\Downloads\\chromedriver_win32\\chromedriver.exe");

		driver = new ChromeDriver();
		driver.get("http://www.way2automation.com/demo.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void windowsHandle() throws InterruptedException {
		//String parentWindow = driver.getWindowHandle();
		driver.findElement(By.xpath("//h2[text()='Draggable']")).click();

	/*	Set<String> childWindows = driver.getWindowHandles();

		for (String child : childWindows) {
			driver.switchTo().window(child);
		}
		driver.switchTo().window(parentWindow);
		System.out.println("Sucessfully switched to Parent Window");
		Thread.sleep(15000); */
		
		Set<String> allWindows = driver.getWindowHandles();
		List<String> window = new ArrayList<>();
		window.addAll(allWindows);
		driver.switchTo().window(window.get(1));
		
		
	}

	@AfterMethod
	public void close() {
		driver.close();
	}

}
