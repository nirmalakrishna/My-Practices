package programs;

public class ObjectCount {

	static int count = 0;

	ObjectCount() {
	//	System.out.println("Inside Constructor");

		count++;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ObjectCount oc = new ObjectCount();
		System.out.println("After first Ob ject" + count);
		int method1value = oc.mthod1(100);	
		System.out.println(method1value);
		String str = oc.method("Hello");
		System.out.println(str);
		ObjectCount oc1 = new ObjectCount();		
		System.out.println(count);
		ObjectCount oc2 = new ObjectCount();
		System.out.println(count);
	}
	
	public int mthod1(int i){
				return  i;
			}
public String method(String s){
	
	return s;
}
}
