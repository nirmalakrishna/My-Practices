package programs;

public class CountRepeatedNumbers {

	public static void main(String[] args) {

		int counter = 0;

		int[] arr = { 1, 2, 3, 4, 5, 5, 6, 4, 4, 4, 2, 1, 8, 9 };

		for (int i = 0; i <= arr.length - 1; i++) {
			// System.out.println("Array elements:" + arr[i]);
			for (int j = i + 1; j <= arr.length - 1; j++) {
				if (arr[i] == arr[j]) {
					counter++;
				}
				
			}
			System.out.println(arr[i] + "****" + counter);
			
		}
	}
}
