package programs;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int number;

		Scanner input = new Scanner(System.in);
		System.out.println("Enter input");
		number = input.nextInt();

		if((number%number)==0){
			System.out.println("Prime");
		}
		else{
			System.out.println("Not Prime Number");
		}
	}

}
