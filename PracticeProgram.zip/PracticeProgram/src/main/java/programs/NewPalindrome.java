package programs;

import java.util.Scanner;

public class NewPalindrome {

	public static void main(String[] args) {

		String rev = "";

		Scanner scan = new Scanner(System.in);

		System.out.println("Enter the Input:");
		String input = scan.next();

			int len = input.length();

		for (int i = len - 1; i >= 0; i--) {
			rev = rev + input.charAt(i);
		}

		System.out.println(rev);
		if (rev.equalsIgnoreCase(input)) {
			System.out.println("The given input is Palindrome");
		} else {
			System.out.println("The given input is not Palindrome");
		} 
		
		//StringBuilder sb = new StringBuilder(input);
		
	//	System.out.println(sb.reverse());
	}

}
