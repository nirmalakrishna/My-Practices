package programs;

public class While {

	public static void main(String[] args) {

		int a = 1;

		while (a <= 10) {
			System.out.println(a);
			a++;
		}

		do

		{
			System.out.println(a);
			a++;
		} while (a < 13);
	}
}
