package programs;

public class ReverseNumber {

	public static void main(String[] args) {
		
		int input = 5189;
		int m,x,a = 0;
		m = input;
		
		while(input>0){
			
			x = input%10;
			a = a*10 + x;
			input = input/10;
			System.out.println(a);
		}
		if(a == m){
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not Palindrome");
		}

	}

}
