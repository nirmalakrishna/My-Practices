package programs;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.testng.annotations.Test;

public class ReadExcel {

	// public static void main(String[] args) throws Exception {
	@Test
	public void readExl() throws IOException {
		FileInputStream fis = new FileInputStream("./data/Test.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheetAt(0);

		// get row count
		int rowCount = sh.getLastRowNum();
		System.out.println(rowCount);

		// get column count
		int colCount = sh.getRow(0).getLastCellNum();
		System.out.println(colCount);

		// loop through the rows
		for (int i = 1; i < rowCount + 1; i++) {
			XSSFRow row = sh.getRow(i);

			for (int j = 0; j < colCount; j++) {
				String cellValue = row.getCell(j).getStringCellValue();
				System.out.println(cellValue);
			}
		}
	}

	@Test
	public void writeExcel() throws IOException {

		FileInputStream fis = new FileInputStream("./data/WriteExcel.xlsx");

		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheet("Sheet1");
		// XSSFRow row = sh.getRow(0);
		Row row = sh.createRow(1);
		Cell col = row.createCell(0);
		col.setCellValue("Created a cell");

		FileOutputStream fos = new FileOutputStream("./data/WriteExcel.xlsx");
		wb.write(fos);
		fos.close();
		System.out.println("Done writing in Excel");

	}
}