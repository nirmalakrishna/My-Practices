package programs;

import java.util.HashMap;
import java.util.Map;

public class MapExample {

	public static void main(String[] args) {

		Map<Integer, String> maps = new HashMap<Integer, String>();
		maps.put(111, "aaa");
		maps.put(222, "bbb");
		maps.put(333, "ccc");

		// Entry is an sub interface of Map, it will be accessed by Map.Entry.
		// Entry contains getKey and getValue method.

		for (Map.Entry m : maps.entrySet()) {
			System.out.println(m.getKey() + "*****" + m.getValue());
		}

		Map<Integer, String> hashMap = new HashMap<Integer, String>();
		hashMap.putAll(maps);
		hashMap.remove(222);
		
		System.out.println(hashMap.size());
		for (Map.Entry hm : hashMap.entrySet()) {
			//System.out.println(hashMap.get(hashMap));
			System.out.println(hm.getKey() + "****" + hm.getValue());
		}
	}

}
