package programs;

public class Palindrome {

	public static void main(String[] args) {
		String input = "malayalam";
		String rev = "";
		int len = input.length();
		System.out.println(len);
		for (int i = len - 1; i >= 0; i--) {
			rev = rev + input.charAt(i);
			// System.out.println(rev);}
		}
		if (input.equals(rev)) {
			System.out.println("Given input is Palindrome");
		} else
			System.out.println("Given input is not Palindrome");

		/*
		 * String original, reverse = ""; Scanner in = new Scanner(System.in);
		 * 
		 * System.out.println("Enter a string to check if it is a palindrome");
		 * original = in.nextLine();
		 * 
		 * int length = original.length();
		 * 
		 * for (int i = length - 1; i >= 0; i--) reverse = reverse +
		 * original.charAt(i);
		 * 
		 * if (original.equals(reverse))
		 * System.out.println("Entered string is a palindrome."); else
		 * System.out.println("Entered string is not a palindrome.");
		 */
	}

}
