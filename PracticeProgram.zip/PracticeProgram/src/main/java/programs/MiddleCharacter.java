package programs;

public class MiddleCharacter {

	public static void main(String[] args) {
		// String input = "MOM0";
		// String input = "NIRMALA";
		String input = "MALLIKA";
		int length = input.length();
		System.out.println("Length of the Word is:" + length);

		int n = length % 2;

		int m = length / 2;
		int char_at = m;

		if (n != 0) {
			char middlechar = input.charAt(char_at);
			System.out.println("Middle Character of " + input + " is " + middlechar);
		} else {
			System.out.println("Cannot determine Middle character");
		}

	}

}
