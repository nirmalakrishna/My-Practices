package programs;

public class StaticExamples {

	static int staticVariable = 10;
	int nonStaticVariable = 20;

	public static void main(String[] args) {
		StaticExamples ex = new StaticExamples();
		ex.nonStatic();
		staticMethod();

	}

	public void nonStatic() {

		System.out.println("I am a Non Static Method trying to access static variable" + staticVariable);
		System.out.println("I am a Non Static Method trying to access non static variable" + nonStaticVariable);
		staticMethod();

	}

	static void staticMethod() {

		System.out.println("I am a Static Method trying to access static variable" + staticVariable);
		StaticExamples exam = new StaticExamples();
		System.out.println("I am a Static Method trying to access non static variable" + exam.nonStaticVariable);
		// nonStatic();
		// Not possible to access a NonStatic Method from a static method as non
		// static method belong to the object itself.

	}

}
