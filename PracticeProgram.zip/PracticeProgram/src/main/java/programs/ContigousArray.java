package programs;

public class ContigousArray {

	public static void main(String[] args) {

		int array[] = { -2, -3, 4, -1, -2, 1, 5, -3 };
		System.out.println("Maximum contiguous sum is " + maxSubArraySum(array));

	}

	static int maxSubArraySum(int array[]) {

		int max_so_far = 0;
		int max_ending_here = 0;
		int size = array.length;

		for (int i = 0; i < size; i++) {
			max_ending_here = max_ending_here + array[i];
			if (max_ending_here < 0)
				max_ending_here = 0;
			if (max_so_far < max_ending_here)
				max_so_far = max_ending_here;

		}
		return max_so_far;
	}

}