package programs;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TransformManager {

	WebDriver driver;

	@Test
	public void BrokenLink() throws AWTException, InterruptedException {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nkrishnamoorthy\\Downloads\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();

		//driver.get("https://qbwidit9051.development.webmd.net/q-bwidit9001_TM/index.cfm ");
		driver.get("https://qbwidit9051.development.webmd.net/q-bwidit9001_TM/expire.cfm?last_get=%2Fq-bwidit9001_TM%2Findex%2Ecfm");
		// driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		Robot rb = new Robot();
		// Thread.sleep(1000);

		StringSelection username = new StringSelection("development\nkrishnamoorthy");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(username, null);
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		rb.keyRelease(KeyEvent.VK_V);
		rb.keyRelease(KeyEvent.VK_CONTROL);

		rb.keyPress(KeyEvent.VK_TAB);
		rb.keyRelease(KeyEvent.VK_TAB);
		Thread.sleep(1000);

		StringSelection password = new StringSelection("Jag)6789");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(password, null);
		rb.keyPress(KeyEvent.VK_CONTROL);
		rb.keyPress(KeyEvent.VK_V);
		rb.keyRelease(KeyEvent.VK_V);
		rb.keyRelease(KeyEvent.VK_CONTROL);

		rb.keyPress(KeyEvent.VK_ENTER);
		rb.keyRelease(KeyEvent.VK_ENTER);

		Thread.sleep(5000);

		driver.manage().window().maximize();

	}

}
