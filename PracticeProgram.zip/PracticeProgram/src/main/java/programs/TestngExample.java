package programs;

import java.util.NoSuchElementException;

import org.testng.annotations.*;

public class TestngExample {

	@Test(priority = 3, invocationCount = 2, expectedExceptions = { ArithmeticException.class,
			NoSuchElementException.class }, expectedExceptionsMessageRegExp = "hello")
	public void testMethod() {
		System.out.println("Test Method");
		throw new ArithmeticException("Throwing Arithmetic Exception");
	}

	@Test(groups = "Dummy", description = "This method is to check Groups named Dummy", priority = 0, invocationCount = 1)
	public void testMethod1() {
		System.out.println("Test Method 1");
	}

	@Test(groups = "Dummy", enabled = false)
	public void testMethod2() {
		System.out.println("Test Method 2");
	}

	@BeforeMethod
	public void beforeMethod() {
		System.out.println("BEfore Method");
	}

	@BeforeClass
	public void beforeClass() {
		System.out.println("BEfore Class");
	}

	@BeforeTest
	public void beforeTest() {
		System.out.println("BEfore Test");
	}

	@BeforeSuite
	public void beforeSuite() {
		System.out.println("BEfore Suite");
	}

	@AfterMethod
	public void afterMethod() {
		System.out.println("After Method");
	}

	@AfterTest
	public void afterTest() {
		System.out.println("After Test");
	}

	@AfterSuite
	public void afterSuite() {
		System.out.println("After Suite");
	}

	@BeforeGroups(value = "Dummy")
	public void beforeGroups1() {
		System.out.println("Before Groups for Dummy");
	}

	@BeforeGroups(value = "Real")
	public void beforeGroups2() {
		System.out.println("Before Groups for Real");
	}

	@AfterGroups(value = "Dummy")
	public void afterGroups1() {
		System.out.println("After Groups for Dummy");
	}

	@AfterGroups(value = "Real")
	public void afterGroups2() {
		System.out.println("After Groups for Real");
	}
}
