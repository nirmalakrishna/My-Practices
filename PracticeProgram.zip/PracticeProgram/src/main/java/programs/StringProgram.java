package programs;

public class StringProgram {

	public static void main(String[] args) {

		System.out.println(reverseString());
		palindromeString();
		System.out.println(capitalizeFirst());
	}

	public static String reverseString() {
		String rev = " ";

		String s = "nirmala";
		char[] ch = s.toCharArray();
		for (int i = ch.length - 1; i >= 0; i--) {
			rev = rev + ch[i];
		}
		return rev;
	}

	public static void palindromeString() {
		String s = "Nirmala";
		String rev = " ";
		char[] ch = s.toCharArray();
		for (int i = ch.length - 1; i >= 0; i--) {
			rev += ch[i];
		}
		if (rev.equals(s)) {
			System.out.println("Given String is a Palindrome");
		} else {
			System.out.println("Given String is Not a Palindrome");
		}
	}
	
	public static String capitalizeFirst(){
		String s = "I have a plan";
		String capitalizeWord = " ";
		String splitStr[] = s.split("\\s");
		for(String each:splitStr){
		String first = 	each.substring(0, 1);
		capitalizeWord+= first.toUpperCase();
		}
		return capitalizeWord;
	}

}
