package programs;

import java.util.Scanner;

public class CompareString {

	public static void main(String[] args) {
		String s1, s2;
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the first string");
		s1 = scan.nextLine();
		System.out.println("Enter the second string");
		s2 = scan.nextLine();

		if (s1.equals(s2)) {
			System.out.println("The given input is same");
		} else {
			System.out.println("The given input are not same");
		}

		char[] ch = s1.toCharArray();
		for(int i=0; i<ch.length;i++){
			//System.out.println(ch[i]);
		}
		
		String s = "Hello";
		
		char[] ch1 = s.toCharArray();
		
		System.out.println(ch1);
	}

}
