package programs;

import java.util.LinkedHashSet;
import java.util.Set;

public class RemoveDuplicates {

	public static void main(String[] args) {

		String str = "Hello";
		char[] ch = str.toCharArray();

		Set<Character> charset = new LinkedHashSet<Character>();
		for (Character c : ch) {

			charset.add(c);
		}

		StringBuilder sb = new StringBuilder();

		for (Character onechar : charset) {

			sb.append(onechar);
		}

		System.out.println(sb.toString());
	}

}
