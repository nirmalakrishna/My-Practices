package programs;

public class StringPractice {

	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();  
        concatWithString();  
        System.out.println("Time taken by Concating with String: "+(System.currentTimeMillis()-startTime)+"ms");  
        startTime = System.currentTimeMillis();  
        concatWithStringBuffer();  
        System.out.println("Time taken by Concating with  StringBuffer: "+(System.currentTimeMillis()-startTime)+"ms");
	}
	/*	String s = "Welcome";
		System.out.println(s.hashCode());
		s = s.concat("World");
		System.out.println(s);
		System.out.println(s.hashCode());
		
		String s1 = "Hello";
		s1 = "World";
		System.out.println(s1);
		String s2 = "World";
	//	s1 = "NewWorld";
		String s3 = s1;
		
		System.out.println(System.identityHashCode(s1));
		System.out.println(System.identityHashCode(s2));
		System.out.println(System.identityHashCode(s3));
		
		
		System.out.println(s1.toLowerCase());
		
		StringBuffer strBuff = new StringBuffer("Nirmala");
		System.out.println(System.identityHashCode(strBuff));
		System.out.println(strBuff);
		strBuff = strBuff.append("Krishnamoorthy");
		System.out.println(System.identityHashCode(strBuff));
		System.out.println(strBuff); */
        public static String concatWithString(){   
        String t = "Java";  
	        for(int i=0; i<10;i++){
	            t = t + "Tpoint";  
	            System.out.println(t);
	        }
	        return t;
	    }  
	    public static String concatWithStringBuffer(){  
	        StringBuffer sb = new StringBuffer("Java"); 
	        for(int i=0;i<10;i++){
	             sb.append("Tpoint");  
	        System.out.println(sb); 
	        }
	        return sb.toString();	        
	}

}
