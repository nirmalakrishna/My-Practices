package programs;

import java.util.ArrayList;
import java.util.Collections;

public class ArraySort {

	public static void main(String[] args) {

		ArrayList<Integer> arrList = new ArrayList<>();

		arrList.add(100);
		arrList.add(20);
		arrList.add(30);
		arrList.add(20);
		arrList.add(40);
		arrList.add(120);
		// List before Sorting
		System.out.println("List before Sorting:");
		for (int i : arrList) {

			System.out.println(i);
		}
		Collections.sort(arrList);
		// List after Sorting
		System.out.println("List after Sorting:");
		for (int i1 : arrList) {
			System.out.println(i1);
		}

		int[] arr = { 1, 2, 3, 4, 5 };

		int temp = 0;
		for (int i = 0; i < arr.length; i++) {

			temp = temp + arr[i];
		}
		System.out.println("The sum of the Array is:" + temp);
		
		String[] str = {"Niki","Paul","John","Rasheed","Wick"};
		
		ArrayList<String> evenStr = new ArrayList<String>();
		
		ArrayList<String> oddStr = new ArrayList<String>();
		
		for(int i = 0;i<str.length;i++){
			if((i%2)==0){
				evenStr.add(str[i]);
			}
			else{
				oddStr.add(str[i]);
			}
			
		}
		System.out.println(evenStr);
		System.out.println(oddStr);
	}
}
