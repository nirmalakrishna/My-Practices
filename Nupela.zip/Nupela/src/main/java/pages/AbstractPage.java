package pages;

import base.WdMethods;
public class AbstractPage extends WdMethods{



}
