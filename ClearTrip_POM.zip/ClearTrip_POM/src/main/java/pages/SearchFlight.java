package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ClearTripMethods;

public class SearchFlight extends ClearTripMethods {

	public SearchFlight(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.ID, using = "FromTag")
	WebElement Fromdropdown;

	@FindBy(how = How.ID, using = "ToTag")
	WebElement Todropdown;

	@FindBy(how = How.XPATH, using = "//*[@id=\"DepartDate\"]")
	WebElement date;

	@FindBy(how = How.ID, using = "RoundTrip")
	WebElement tripradiobtn;

	@FindBy(how = How.ID, using = "Adults")
	WebElement adultdrop;

	@FindBy(how = How.ID, using = "SearchBtn")
	WebElement searchbutton;

	public SearchFlight enterFrom(String source) {
		type(Fromdropdown, source);
		return this;
	}

	public SearchFlight typeSource(String sourceCity, String listxpath, String sourceText) throws InterruptedException {
		selectSource(Fromdropdown, sourceCity, listxpath, sourceText);
		return this;
	}

	public SearchFlight enterTo(String destination) {
		type(Todropdown, destination);
		return this;
	}

	public SearchFlight enterDepartDate(String departDate) {
		type(date, departDate);
		return this;
	}

	public SearchFlight enterAdult(String count) {
		selectByValue(adultdrop, count);
		return this;
	}

	public void clickSearch() {
		click(searchbutton);

	}

}
