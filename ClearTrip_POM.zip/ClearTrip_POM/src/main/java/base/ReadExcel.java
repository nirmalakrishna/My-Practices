package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {


	public static String[][] fetchData() throws IOException {
		
		String[][] data = null;

		FileInputStream fis = new FileInputStream(new File("D:\\Eclipse Workspace\\TC001.xlsx"));
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sheet = wb.getSheetAt(0);

		int rowCount = sheet.getLastRowNum();
		int colCount = sheet.getRow(0).getLastCellNum();

		data = new String[rowCount][colCount];

		for (int i = 1; i <= rowCount; i++) {

			XSSFRow row = sheet.getRow(i);

			for (int j = 0; j < colCount; j++) {

				String cellValue = row.getCell(j).getStringCellValue();

				data[i - 1][j] = cellValue;

				// System.out.println(cellValue);
			}
		}

		fis.close();
		wb.close();

		return data;

	}

}
