package base;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ClearTripMethods implements ClearTripInterface {

	protected WebDriver driver;
	
	public WebElement locateElement(String how, String using) {
		WebElement ele = null;
		switch (how) {
		case ("id"):
			ele = driver.findElement(By.id(using));
			break;
		case ("name"):
			ele = driver.findElement(By.name(using));
			break;

		case ("linktext"):
			ele = driver.findElement(By.linkText(using));
			break;

		case ("classname"):
			ele = driver.findElement(By.className(using));
			break;
		case ("xpath"):
			ele = driver.findElement(By.xpath(using));
			break;
		default:
			System.out.println("The given locator" + how + "is not found");
			break;
		}
		return ele;
	}

	public void click(WebElement ele) {
		ele.click();
		snapShot();

	}

	public void clr(WebElement ele) {
		ele.clear();
	}

	public void type(WebElement ele, String data) {
		ele.sendKeys(data);
		snapShot();

	}

	public void closeBrowser() {
		// driver.close();
		driver.quit();
	}

	public void selectByIndex(WebElement ele, int index) {
		new Select(ele).selectByIndex(index);

	}

	public void selectByValue(WebElement ele, String data) {
		new Select(ele).selectByValue(data);

	}

	public void selectByVisibleText(WebElement ele, String data) {
		new Select(ele).selectByVisibleText(data);

	}

	public String getText(WebElement ele) {

		return ele.getText();
	}

	public boolean verifyText(WebElement ele, String data) {
		return ele.getText().equals(data);

	}

	public void snapShot() {

		try {
			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE),
					new File("D:\\Eclipse Workspace\\" + System.currentTimeMillis() + ".jpg"));
		} catch (WebDriverException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void selectSource(WebElement ele, String data, String using, String text) throws InterruptedException {
		ele.sendKeys(data);
		Thread.sleep(10000);
		List<WebElement> sourceoptions = driver.findElements(By.xpath(using));
		// "//ul[@id='ui-id-1']//child::li//a"
		// the above or the below
		// List<WebElement> options =
		// driver.findElements(By.xpath("//ul[@id='ui-id-1']//li//a"));

		sourceoptions.get(2).click();

		for (WebElement option : sourceoptions) {

			if (option.getText().contains(text)) {
				option.click();
				break;
			} else {
				System.out.println("Element not found");
			}
		}
	}

}
