package base;

import org.openqa.selenium.WebElement;

public interface ClearTripInterface {

	public WebElement locateElement(String how, String using);

	public void click(WebElement ele);

	public void clr(WebElement ele);

	public void type(WebElement ele, String data);

	public void selectByIndex(WebElement ele, int index);

	public void selectByValue(WebElement ele, String data);

	public void selectByVisibleText(WebElement ele, String data);

	public String getText(WebElement ele);

	public boolean verifyText(WebElement ele, String data);
}
