package base;

import org.openqa.selenium.WebElement;

public interface Base {

	// This method will invoke the application in the specified browser
	public void lauchApp(String browserName, String URL);

	// This method locates an element based on the value
	public WebElement locateElement(String how, String using);

	// This method locates an element and performs click action
	public void click(WebElement ele);

	// This method locates an element and clear text from text box
	public void clear(WebElement ele);

	// This method locates an element and enters the specified data
	public void enterText(WebElement ele, String data);

	// This method locates an alert and accepts the alert
	public void alertAccept();

	// This method locates an alert and dismiss the alert
	public void alertDecline();

	// This method locates an alert and enters the specified data
	public void alertSendText(String data);

	// This method locates an alert and retrieves the text present in the alert
	public String alertGetText();

	// This method switches control from parent to child window and vice versa
	public void switchWindows(int index);

	// This method locates an element and retrieves the text present in the
	// element
	public String getText(WebElement ele);

	// This method locates an element and verifies the text with the given data
	public boolean verifyText(WebElement ele, String data);

	// This method locates a dropdown and selects value based on Value
	public void selectByValue(WebElement ele, String data);

	// This method locates a dropdown and selects value based on Index
	public void selectByIndex(WebElement ele, int data);

	// This method locates a dropdown and selects value based on Text
	public void selectByText(WebElement ele, String data);

	// This method verifies the browser title with the given data
	public boolean verifyTitle(String title);

}
