package base;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public abstract  class AppMethods implements Base {

	protected WebDriver driver;

	public void lauchApp(String browserName, String URL){
		
	}

	public WebElement locateElement(String how, String using) {

		WebElement ele = null;

		switch (how) {
		case ("id"):
			ele = driver.findElement(By.id(using));
			break;
		case ("name"):
			ele = driver.findElement(By.name(using));
			break;
		case ("tagname"):
			ele = driver.findElement(By.tagName(using));
			break;
		case ("css"):
			ele = driver.findElement(By.cssSelector(using));
			break;
		case ("linkText"):
			ele = driver.findElement(By.linkText(using));
			break;
		case ("xpath"):
			ele = driver.findElement(By.xpath(using));
			break;
		case ("partialLinkText"):
			ele = driver.findElement(By.partialLinkText(using));
			break;
		case ("className"):
			ele = driver.findElement(By.className(using));
			break;
		default:
			System.out.println("The given locator " + how + " is not correct");
			break;
		}
		return ele;
	}

	public void click(WebElement ele) {
		ele.click();
	}

	public void clear(WebElement ele) {
		ele.clear();
	}

	public void enterText(WebElement ele, String data) {
		ele.sendKeys(data);
	}

	public void alertSendText(String data) {
		driver.switchTo().alert().sendKeys(data);
	}

	public void switchWindows(int index) {
		Set<String> allWindows = driver.getWindowHandles();
		List<String> windowList = new ArrayList<String>();
		windowList.addAll(allWindows);
		driver.switchTo().window(windowList.get(index));
	}

	public String getText(WebElement ele) {
		return ele.getText();
	}

	public boolean verifyText(WebElement ele, String data) {
		return ele.getText().equals(data);
	}

	public void select(WebElement ele, String type, String textOrValue) {
		if (type.equalsIgnoreCase("text"))
			new Select(ele).selectByVisibleText(textOrValue);
		else
			new Select(ele).selectByValue(textOrValue);
	}

	public void selectByValue(WebElement ele, String data) {
		select(ele, "value", data);
	}

	public void selectByIndex(WebElement ele, int data) {
		new Select(ele).selectByIndex(data);
	}

	public void selectByText(WebElement ele, String data) {
		select(ele, "text", data);
	}

	public boolean verifyTitle(String title) {
		return driver.getTitle().equalsIgnoreCase(title);
	}

	private Alert ale() {
		return driver.switchTo().alert();
	}

	public void alertAccept() {
		ale().accept();
	}

	public void alertDecline() {
		ale().dismiss();
	}

	public String alertGetText() {
		return ale().getText();
	}

}
