package base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import dataProvider.DbProvider;
import dataProvider.ExcelProvider;

public class Annotations {

	public Properties config;
	public String browserName;
	public WebDriver driver;
	public String dataSource;
	protected String dataSheetName;

	@BeforeSuite
	public void beforeSuite() throws FileNotFoundException, IOException {
		config = new Properties();
		config.load(new FileInputStream(new File("./src/main/resources/config.properties")));
	}
	
	@Parameters({"siteurl"})
	@BeforeMethod
	public void beforeMethod(String url) {
		if (browserName.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
			driver = new ChromeDriver();
		} else {
			System.setProperty("webdriver.gecko.driver", "./drivers/geckodriver.exe");
			driver = new FirefoxDriver();
		}

	driver.get(url);
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
}
	
/*	@BeforeMethod
	public void launchApp(String siteurl) {
		driver.get(siteurl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);

	} **/

	@AfterMethod
	public void afterMethod() {
		driver.quit();
	}

	@DataProvider(name = "fetchData")
	public String[][] getData() throws IOException {
		if (dataSource.equalsIgnoreCase("excel")) {
			ExcelProvider excelProvider = new ExcelProvider();
			return excelProvider.readFromExcel(dataSheetName);
		} else
			return DbProvider.readFromDb(dataSheetName);

	}
}
