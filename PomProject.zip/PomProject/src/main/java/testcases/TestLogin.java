package testcases;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import base.Annotations;
import pages.LoginPage;

public class TestLogin extends Annotations {

	@BeforeClass
	public void setValues() {
		browserName = "chrome";
		dataSource = "Excel";
		dataSheetName = "Login";
	}

	@Test(dataProvider = "fetchData", description = "To check the login functionality")
	public void TC001(String username, String password) {
		LoginPage loginpage = new LoginPage(driver);

		loginpage.enterUserName(username).enterPassword(password).clickSignin();

	}

}
