package dataProvider;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class DbProvider {
	
	public static String[][] readFromDb(String dataSheetName) throws IOException {
		String[][] data = null;
		try {
			FileInputStream fis = new FileInputStream("./data/" + dataSheetName + ".xlsx");
			XSSFWorkbook wb = new XSSFWorkbook(fis);
			XSSFSheet sheet = wb.getSheetAt(0);

			// get the number of rows
			int rowCount = sheet.getLastRowNum();

			// get the number of columns
			int colCount = sheet.getRow(0).getLastCellNum();

			// declaring the size of the array
			data = new String[rowCount][colCount];

			// loop through the rows

			for (int i = 1; i < rowCount + 1; i++) {

				XSSFRow row = sheet.getRow(i);

				for (int j = 0; j < colCount; j++) {

					String cellValue = row.getCell(j).getStringCellValue();

					data[i - 1][j] = cellValue;
				}

			}

			fis.close();
			wb.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;

	}

}
