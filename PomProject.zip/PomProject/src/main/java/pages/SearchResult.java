package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import base.AppMethods;

public class SearchResult extends AppMethods {

	public SearchResult(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

}
