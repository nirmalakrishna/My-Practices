package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.AppMethods;

public class HomePage extends AppMethods {

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(how = How.NAME, using = "tripType")
	WebElement tripType;

	public HomePage selectTripType() {
		click(tripType);
		return this;
	}

	@FindBy(how = How.NAME, using = "passCount")
	WebElement passengerCount;

	public HomePage selectPassengerCount(String data) {
		selectByValue(passengerCount, data);
		return this;
	}

	@FindBy(how = How.NAME, using = "fromPort")
	WebElement departureFrom;

	public HomePage selectSource(String data) {
		selectByText(departureFrom, data);
		return this;
	}

	@FindBy(how = How.NAME, using = "fromMonth")
	WebElement departureMonth;

	public HomePage selectMonth(int data) {
		selectByIndex(departureMonth, data);
		return this;
	}

	@FindBy(how = How.NAME, using = "fromDay")
	WebElement departureDate;

	public HomePage selectDate(String data) {
		selectByValue(departureDate, data);
		return this;
	}

	@FindBy(how = How.NAME, using = "toPort")
	WebElement arrivingFrom;

	public HomePage selectDestination(String data) {
		selectByText(arrivingFrom, data);
		return this;
	}

	@FindBy(how = How.NAME, using = "toMonth")
	WebElement arrivingMonth;

	public HomePage selectArrivingMonth(int data) {
		selectByIndex(arrivingMonth, data);
		return this;
	}

	@FindBy(how = How.NAME, using = "toDay")
	WebElement arrivingDate;

	public HomePage selectArrivingDate(String data) {
		selectByValue(arrivingDate, data);
		return this;
	}

	@FindBy(how = How.NAME, using = "findFlights")
	WebElement searchFlight;

	public SearchResult clickFindFlights() {
		click(searchFlight);
		return new SearchResult(driver);
	}

}
